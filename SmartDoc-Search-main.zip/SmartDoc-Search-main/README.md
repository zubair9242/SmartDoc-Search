# SmartDoc-Search
A personal AI-powered search engine for your documents. Upload files and ask questions to get instant, context-aware answers extracted directly from your data.
